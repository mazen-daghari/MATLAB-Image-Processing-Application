clear;
clear all;
%lecture de l'image
image=imread ('BIRD.BMP');
%affiche l'image
subplot(5,5,1);
imshow(image)
title('image originale')
%afficher la taille de l'image
S= size(image)
%inversion de couleur
im=imread('BIRD.BMP');
y=255-im
subplot(5,5,2);
imshow(y);
title('image invers�')
%affichage d'un bloc
x=input('donner une valeur de x=')
disp(sum(image(:) == x));
for i=1:128
    for j=1:128
        bloc(i,j)=im(i,j);
    end;
end;
subplot(5,5,3);
imshow(bloc);
title('bloce de limage')
%nombre d'ocurrence de x dans une image 
val=input('entrer le nbr d occurence x = ');
Occ = sum(im(:) == val);
Occurence=num2str(Occ)

%rotation de l'image
a=input('donner une angle a=')
b=imrotate(im,a);
subplot(5,5,4)
imshow(b)
title('image avec rotation')

%histogramme 
subplot(5,5,5)
imhist(im)
title('histogramme')

%profile d'intensite Ligne et colonne
 x1=input('donner la ligne pour afficher le profil\n'); 
 y1=input('donner la colonne pour afficher le profil\n'); 
 b=im(x1,:)
 subplot(5,5,6)
 plot(b)
 title('Profil de la ligne ');
 xlabel('Colones')
 ylabel('Niveaux de gris');
 b1=im(:,y1)
 subplot(5,5,7)
 plot(b1) 
 title('Profil de la colonne ');
 xlabel('Lignes')
 ylabel('Niveaux de gris');
 
% Scanning 
px=input('donner la valeur de pixel pour le scanning =')
im1=imread('BIRD.BMP');
 for i=1: 256;
    for j=1 : 256;
        if im1(i,j)~=px;
         im5(i,j)=0;

        else
            im5(i,j)=255;
    
        end   
       end 
 end 
subplot(5, 5, 8), imshow(im5), title('Resultat du scanning');

%ajouter de bruit SALT AND PEPPER
subplot(5,5,9);
noiseIm = imnoise(im,'salt & pepper',0.02);
imshow(noiseIm); 
title('image avec bruit salt and pepper');

%ajouter de bruit GAUSSIAN
subplot(5,5,10);
noiseIm1=imnoise(image, 'gaussian',0.02);
imshow(noiseIm1); 
title('image avec gaussian');

%ajouter de bruit SPECKLE 
noiseIm2 = imnoise(im,'speckle',0.01)
subplot(5,5,11),imshow(noiseIm2) 
title('Image bruit�e: speckle')

%filtre moyenne salt&pepper
N1 = fspecial('moyenne'); %par defaut 3*3
f1 = imfilter(noiseIm,N1) ;
subplot(5,5,12)
imshow(f1) 
title('filtre moyenne 3x3 SP') ;

%filtre moyenne salt&pepper
N2 = fspecial('moyenne',[5,5]);
f2 = imfilter(noiseIm,N2) ;
subplot(5,5,13)
imshow(f2) 
title('filtre moyenne5x5 SP') ;

%filtre medium salt&pepper
s=medfilt2(noiseIm,[3 3]);
subplot(5,5,14)
imshow(s) 
title('filtre medium 3x3 SP');

%filtrage medium 5x5 salt & pepper
s1 = medfilt2(noiseIm,[5 5]);
subplot(5,5,15),imshow(s1)
title('filtre medium 5x5 SP')

%filtre moyenne gaussian
N2 = fspecial('moyenne'); %par defaut 3*3
f3 = imfilter(noiseIm1,N1) ;
subplot(5,5,16)
imshow(f3) 
title('filtre moyenne 3x3 G') ;

%filtre moyenne gaussian
N2 = fspecial('moyenne',[5,5]);
f4 = imfilter(noiseIm1,N2) ;
subplot(5,5,17)
imshow(f4) 
title('filtre moyenne5x5 G') ;

%filtre medium gaussian
s2=medfilt2(noiseIm1,[3 3]);
subplot(5,5,18)
imshow(s2) 
title('filtre medium 3x3 G');

%filtrage medium 5x5 gaussian
s3 = medfilt2(noiseIm1,[5 5]);
subplot(5,5,19),imshow(s3)
title('filtre medium 5x5 G')

%filtre moyenne SPECKLE
N1 = fspecial('moyenne'); %par defaut 3*3
f5 = imfilter(noiseIm2,N1) ;
subplot(5,5,20)
imshow(f5) 
title('filtre moyenne 3x3 S') ;

%filtre moyenne SPECKLE
N2 = fspecial('moyenne',[5,5]);
f6 = imfilter(noiseIm2,N2) ;
subplot(5,5,21)
imshow(f6) 
title('filtre moyenne5x5') ;

%filtre medium SPECKLE
s4=medfilt2(noiseIm2,[3 3]);
subplot(5,5,22)
imshow(s4) 
title('filtre medium 3x3 S');

%filtrage medium 5x5 SPECKLE
s5 = medfilt2(noiseIm2,[5 5]);
subplot(5,5,23),imshow(s5)
title('filtre medium 5x5 S')

%calcul de PSNR1 Bruit salt and pepper moyenne 3x3
fprintf('Bruit salt & pepper');
pnsrvalue= psnr(f1, im);
fprintf('la valeur de PSNR est: %fdB\n\n', pnsrvalue);

%calcul de PSNR1 Bruit gaussian moyenne 3x3
fprintf('Bruit gaussian');
pnsrvalue= psnr(f3, im);
fprintf('la valeur de PSNR est: %fdB\n\n', pnsrvalue);

%calcule de PSNR1 Bruit poisson moyenne 3x3
fprintf('Bruit speckle');
pnsrvalue= psnr(f5, im);
fprintf('la valeur de PSNR est: %fdB\n\n', pnsrvalue);

%calcul de PSNR1 Bruit salt and pepper medium 3x3
fprintf('Bruit salt & pepper');
pnsrvalue= psnr(s, im);
fprintf('la valeur de PSNR est: %fdB\n\n', pnsrvalue);

%calcul de PSNR1 Bruit gaussian medium 3x3
fprintf('Bruit gaussian');
pnsrvalue= psnr(s2, im);
fprintf('la valeur de PSNR est: %fdB\n\n', pnsrvalue);

%calcul de PSNR1 Bruit poisson medium 3x3
fprintf('Bruit speckle');
pnsrvalue= psnr(s4, im);
fprintf('la valeur de PSNR est: %fdB\n\n', pnsrvalue);

%calcul de PSNR1 Bruit salt and pepper moyenne 5x5
fprintf('Bruit salt & pepper');
pnsrvalue= psnr(f2, im);
fprintf('la valeur de PSNR est: %fdB\n\n', pnsrvalue);

%calcul de PSNR1 Bruit gaussian moyenne 5x5
fprintf('Bruit gaussian');
pnsrvalue= psnr(f4, im);
fprintf('la valeur de PSNR est: %fdB\n\n', pnsrvalue);

%calcul de PSNR1 Bruit poisson moyenne 5x5
fprintf('Bruit speckle');
pnsrvalue= psnr(f6, im);
fprintf('la valeur de PSNR est: %fdB\n\n', pnsrvalue);

%calcul de PSNR1 Bruit salt and pepper medium 5x5
fprintf('Bruit salt & pepper');
pnsrvalue= psnr(s1, im);
fprintf('la valeur de PSNR est: %fdB\n\n', pnsrvalue);

%calcul de PSNR1 Bruit gaussian medium 5x5
fprintf('Bruit gaussian');
pnsrvalue= psnr(s3, im);
fprintf('la valeur de PSNR est: %fdB\n\n', pnsrvalue);

%calcul de PSNR1 Bruit poisson medium 5x5
fprintf('Bruit speckle');
pnsrvalue= psnr(s5, im);
fprintf('la valeur de PSNR est: %fdB\n\n', pnsrvalue);